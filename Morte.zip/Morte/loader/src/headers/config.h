#pragma once

#define HTTP_SERVER "34.252.223.26"
#define HTTP_PORT 80

#define TFTP_SERVER "34.252.223.26"
