#pragma once

#define HTTP_SERVER "88.214.56.195"
#define HTTP_PORT 80

#define TFTP_SERVER "88.214.56.195"
